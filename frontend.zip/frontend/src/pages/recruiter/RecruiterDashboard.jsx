/*
==========================================
Component: RecruiterDashboard

Purpose:
Provides recruiters with a summary of ongoing recruitment activities:
stats, recent drives, latest applicants, upcoming interviews, and
notifications (spec Part 4).

Current Features:
- Statistic cards (active drives, applications, shortlisted, offers)
- Recent placement drives table
- Latest applicants table
- Upcoming interviews list
- Notifications preview

Future Backend Integration:
Replace mock getRecruiterDashboard() with GET /recruiter/dashboard.
==========================================
*/

import { useEffect, useState } from 'react'
import { Briefcase, ClipboardList, ListChecks, UserCheck, FolderOpen } from 'lucide-react'
import PageHeader from '../../components/PageHeader'
import StatisticCard from '../../components/StatisticCard'
import Card from '../../components/Card'
import Table from '../../components/Table'
import Badge from '../../components/Badge'
import SkeletonLoader from '../../components/SkeletonLoader'
import { getRecruiterDashboard } from '../../services/recruiterService'
import { formatDate } from '../../utils/formatDate'
import DashboardBarChart from '../../components/charts/DashboardBarChart'
import DashboardPieChart from '../../components/charts/DashboardPieChart'

export default function RecruiterDashboard() {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)

  // useEffect(() => {
  //   // Backend Integration: replace with the real dashboard API response.
  //   getRecruiterDashboard().then((res) => {
  //     setData(res)
  //     setLoading(false)
  //   })
  // }, [])
  useEffect(() => {
    async function fetchDashboard() {
      try {
        const res = await getRecruiterDashboard()
        setData(res)
      } catch (error) {
        console.error('Error fetching recruiter dashboard:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchDashboard()
  }, [])

  const recruitmentData = [
    {
      stage: 'Applications',
      count: data?.stats?.applicationsReceived ?? 0,
    },
    {
      stage: 'Shortlisted',
      count: data?.stats?.candidatesShortlisted ?? 0,
    },
    {
      stage: 'Selected',
      count: data?.stats?.selectedCandidates ?? 0,
    },
  ]

  const hiringData = [
    {
      name: 'Selected',
      value: data?.stats?.selectedCandidates ?? 0,
    },
    {
      name: 'Remaining',
      value: Math.max(
        (data?.stats?.applicationsReceived ?? 0) -
          (data?.stats?.selectedCandidates ?? 0),
        0
      ),
    },
  ]

  const selectionRate = `${Math.round(
    ((data?.stats?.selectedCandidates ?? 0) /
      Math.max(data?.stats?.applicationsReceived ?? 1, 1)) *
      100
  )}%`

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Recruiter Dashboard"
        description="A quick summary of your recruitment activities."
        breadcrumb={['Dashboard']}
      />

      {loading || !data ? (
        <SkeletonLoader rows={6} />
      ) : (
        <>
          <div className="flex flex-col gap-4">
            {/* Top Row */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {/* <div className="h-44"> */}
                <StatisticCard
                  title="Total Drives"
                  value={data.stats.totalDrives}
                  icon={FolderOpen}
                />
              {/* </div> */}

              {/* <div className="h-44"> */}
                <StatisticCard
                  title="Active Drives"
                  value={data.stats.activeDrives}
                  icon={Briefcase}
                />
              {/* </div> */}
{/* 
              <div className="h-44"> */}
                <StatisticCard
                  title="Applications Received"
                  value={data.stats.applicationsReceived}
                  icon={ClipboardList}
                />
              {/* </div> */}
            </div>

            {/* Bottom Row */}
            <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
              <StatisticCard
                title="Candidates Shortlisted"
                value={data.stats.candidatesShortlisted}
                icon={ListChecks}
              />

              <StatisticCard
                title="Selected Candidates"
                value={data.stats.selectedCandidates}
                icon={UserCheck}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">

            <DashboardBarChart
              title="Recruitment Funnel"
              data={recruitmentData}
              xKey="stage"
              dataKey="count"
              color="#22c55e"
            />

            <DashboardPieChart
              title="Hiring Success"
              data={hiringData}
              centerText={selectionRate}
              subtitle="Selection Rate"
            />

          </div>

          {/* <Card title="Recent Placement Drives">
            <Table
              columns={[
                { key: 'company', header: 'Company' },
                { key: 'role', header: 'Role' },
                { key: 'applications', header: 'Applications' },
                { key: 'deadline', header: 'Deadline', render: (r) => formatDate(r.deadline) },
                { key: 'status', header: 'Status', render: (r) => <Badge label={r.status} /> },
              ]}
              rows={data.recentDrives}
              emptyMessage="You have not created any placement drives yet."
            />
          </Card>

          <Card title="Latest Applicants">
            <Table
              columns={[
                { key: 'name', header: 'Student Name' },
                { key: 'drive', header: 'Drive' },
                { key: 'department', header: 'Department' },
                { key: 'cgpa', header: 'CGPA' },
                { key: 'appliedDate', header: 'Applied Date', render: (r) => formatDate(r.appliedDate) },
                { key: 'status', header: 'Status', render: (r) => <Badge label={r.status} /> },
              ]}
              rows={data.latestApplicants}
              emptyMessage="No applicants yet."
            />
          </Card>

          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            <Card title="Upcoming Interviews">
              <ul className="flex flex-col divide-y divide-gray-100">
                {data.upcomingInterviews.map((i) => (
                  <li key={i.id} className="flex items-center justify-between py-3 text-sm">
                    <div>
                      <p className="font-medium text-gray-800">{i.studentName}</p>
                      <p className="text-xs text-gray-500">{i.role} · {formatDate(i.date)} · {i.time}</p>
                    </div>
                    <Badge label={i.mode} color="purple" />
                  </li>
                ))}
              </ul>
            </Card>

            <Card title="Notifications">
              <ul className="flex flex-col divide-y divide-gray-100">
                {data.notifications.map((n) => (
                  <li key={n.id} className="flex items-center justify-between py-3 text-sm">
                    <p className="font-medium text-gray-800">{n.title}</p>
                    <span className="text-xs text-gray-400">{n.time}</span>
                  </li>
                ))}
              </ul>
            </Card>
          </div> */}
        </>
      )}
    </div>
  )
}
